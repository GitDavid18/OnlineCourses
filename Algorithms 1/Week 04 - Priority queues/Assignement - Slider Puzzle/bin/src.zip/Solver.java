import java.util.Iterator;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;

public class Solver {
    private Board initial = null;
    private int moves = 0;
//    private MinPQ<Board> solutionSequence = new MinPQ<Board>();
    private MinPQ<SearchNode> boardPQ = new MinPQ<SearchNode>();
    private Board[] sequence; 
    private Boolean isSolvable = false;
    
    
    //SearchNode Class
    private class SearchNode implements Comparable<SearchNode>{
        Board thisBoard = null;
        SearchNode prevSearchNode = null;
        int manhattan = 0;
        int priority = 0;
        int movesToThis = 0;
        
        SearchNode (Board b, SearchNode prevNode){
            thisBoard = b;
            prevSearchNode = prevNode;
            manhattan = b.manhattan();
            movesToThis = moves;
            priority = movesToThis + manhattan;
        }
        // +1 if this is greater , -1 if that is greater
        @Override
        public int compareTo(SearchNode that) {
//            if (that.equals(this)) return 0;
            if (that.priority > this.priority) return -1;
            if (that.priority < this.priority) return +1;
            if (that.manhattan < this.manhattan) return -1;
            if (that.manhattan > this.manhattan) return +1;
            return 0;
        }
        
    }

    
    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        if(initial == null) throw new IllegalArgumentException();
        this.initial = initial;
        SearchNode initialNode = new SearchNode(initial, null);
        boardPQ.insert(initialNode);
        if (isSolvable()) {
            moves = 0;

            sequence = new Board[boardPQ.size()];

    	    while(!boardPQ.isEmpty()) {
 	            sequence[moves++] = boardPQ.delMin().thisBoard ;
    	    }
    	    moves--;
    	}
//    	    System.out.println("Moves to find solution: " + moves());
    	
    	
    }
    
    private SearchNode aStarStep (SearchNode currentSearchNode) {
    	SearchNode minPrioNode = null;
//        MinPQ<SearchNode> helpPQ = new MinPQ<SearchNode>();
        for(Board neighbor : currentSearchNode.thisBoard.neighbors()) {
//        	System.out.println("Prio" + neighbor.toString());
        	
        	if(minPrioNode == null) {
        		minPrioNode = new SearchNode(neighbor, currentSearchNode);
        	}else       	{
        		if(currentSearchNode.prevSearchNode != null ) {
        			if( !neighbor.equals(currentSearchNode.prevSearchNode.thisBoard)) {
//        				SearchNode bla = new SearchNode(neighbor, currentSearchNode);
        				if(neighbor.manhattan() < minPrioNode.manhattan) {
            				minPrioNode = new SearchNode(neighbor, currentSearchNode);	
            			}
        			}
        		}else {
        			if(new SearchNode(neighbor, currentSearchNode).priority < minPrioNode.priority) {
        				minPrioNode = new SearchNode(neighbor, currentSearchNode);	
        			}
        			
        		}
        	}
            
        }  	
        return minPrioNode;

    }

    // is the initial board solvable? (see below)
    public boolean isSolvable() {
//    	System.out.println("Is Solvable?");
    	SearchNode iniNode = new SearchNode(initial, null);
    	SearchNode twinNode = new SearchNode(initial.twin(), null);
    	if(iniNode.thisBoard.isGoal()){
    		return true;
    	}
    	if(twinNode.thisBoard.isGoal()){
    		return false;
    	}
//	    System.out.println(iniNode.thisBoard.toString());
//	    System.out.println(twinNode.thisBoard.toString());
//    	if(!iniNode.thisBoard.isGoal() && !twinNode.thisBoard.isGoal()) {
//    	while(!iniNode.thisBoard.isGoal() && !twinNode.thisBoard.isGoal()) { //  && !twinNode.thisBoard.isGoal()
    		while(true) {
    			SearchNode iniSave = new SearchNode (aStarStep(iniNode).thisBoard, iniNode);
        		SearchNode twinSave = new SearchNode (aStarStep(twinNode).thisBoard, twinNode);
        		iniNode = iniSave;
        	    twinNode = twinSave;
        	    boardPQ.insert(iniNode);
        	    
//        	    System.out.println(iniNode.thisBoard.toString());
//        	    System.out.println(twinNode.thisBoard.toString());
        	    if (twinNode.thisBoard.isGoal()) {
        	        return false;
        	    }
        	    if(iniNode.thisBoard.isGoal()) {
        	    	return true;
        	    }	
    		}
    	    
//    	}
//    	System.out.println("Is solved board..");
//        return true;
    }

    // min number of moves to solve initial board
    public int moves() {
    	return moves;
    }

    // sequence of boards in a shortest solution
    public Iterable<Board> solution(){
        return new sequenceOfSolution();
//    	return new sequenceOfSolution();
    }
    
    private class sequenceOfSolution implements Iterable<Board>{
//all searchnodes need to be safed and returned here
    	
    	
        @Override
        public Iterator<Board> iterator() {
        	return new solutionIterator();
//            return solutionSequence.iterator();
//               return new solutionIterator();
        }
        
    }
    
    private class solutionIterator implements Iterator<Board>{
//        SearchNode thisNode = new SearchNode(null, null);
        
        int current = moves;
        
        @Override
        public boolean hasNext() {
//            if (current < sequence.length) return true;
        	if (current >= 0) return true;
            else return false;
        }

        @Override
        public Board next() {
        	if(hasNext() ) { //&& sequence[current + 1] != null && current <= moves
        		return sequence[current--];	
        	}else {
        		return null;
        	}
            
        }
        
        public void remove() { throw new UnsupportedOperationException();}
        
    }

    // test client (see below) 
    public static void main(String[] args) {
        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] blocks = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);
        System.out.println(initial.toString());

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }

}