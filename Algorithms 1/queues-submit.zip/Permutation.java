import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class Permutation {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        RandomizedQueue<String> myQueue = new RandomizedQueue<String>();
        
        StdOut.print("Insert a k:");
        int k = StdIn.readInt();
        while(!StdIn.isEmpty()) {
            myQueue.enqueue(StdIn.readString());
        }
        
        while (k > 0) {
            k--;
            StdOut.println( myQueue.dequeue());
        }
        
        
    }

}
